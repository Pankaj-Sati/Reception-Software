<?php

/*
	This file stores all the constants for error/ success messages that are sent to the client
*/

define('DATABASE_CONNECTION_ERROR', 450);
define('NO_RECORD_FOUND', 401);
define('INCOMPLETE_DATA', 402);
define('INSERT_ERROR', 403);

define('SUCCESS', 200);


?>