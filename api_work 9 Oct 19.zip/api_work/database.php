<?php
class Database{

	Private $host='localhost';
	Private $username='dsdlawfi_dsduser';
	Private $password='GT0?q**g%GQL';
	Private $db_name='dsdlawfi_reception';
	public $conn;

	public function getConnection()
	{
		$this->conn=null;
		try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            return false;
        }
 
        return $this->conn;
	}



}
?>