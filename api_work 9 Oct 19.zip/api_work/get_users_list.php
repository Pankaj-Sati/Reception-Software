<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
//get database connection
include_once 'database.php';
include_once 'error_constants.php'; //This file contains all the codes that we send in case of error or success


 
$database = new Database();
$db = $database->getConnection();

if($db==false)
{
	$error=['code'=>DATABASE_CONNECTION_ERROR,'message'=>'Database Connection Error'];
        	echo json_encode($error);
        	exit;
}

$selectQuery="select id,name,username from admin where usertype_id IN (6,7) and status='0' and flag ='0' ORDER BY name ASC";

$user_list=$db->prepare($selectQuery);
$user_list->execute();
$get_user_list=$user_list->fetchAll(\PDO::FETCH_ASSOC);
	if($user_list->rowCount() > 0)
	{
		echo json_encode($get_user_list); 
	}
	else
	{
		$error=['code'=>NO_RECORD_FOUND,'message'=>'Record not found'];
		echo json_encode($error);
	}

?>