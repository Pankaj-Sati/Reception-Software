<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
//get database connection
include_once 'database.php';
include_once 'error_constants.php'; //This file contains all the codes that we send in case of error or success


 
$database = new Database();
$db = $database->getConnection();

if($db==false)
{
	$error=['code'=>DATABASE_CONNECTION_ERROR,'message'=>'Database Connection Error'];
        	echo json_encode($error);
        	exit;
}


	 $client_type   = trim(addslashes($_REQUEST['client_type']));
	 $name       = trim(addslashes($_REQUEST['name']));
	 $contact1    = trim(addslashes($_REQUEST['contact']));
	 $contact= preg_replace('/[^0-9]/','',$contact1);
	$appointment_with= trim(addslashes($_REQUEST['appointment_with']));
	$case_no      = trim(addslashes($_REQUEST['case_no']));
	$address      = trim(addslashes($_REQUEST['address']));
	$email_id      = trim(addslashes($_REQUEST['email_id']));
	$case_type      = trim(addslashes($_REQUEST['case_type']));
	$token_send = 'TOKEN ASSIGN';

	if(!empty($client_type) && !empty($name) && !empty($contact))
	{
		
		if($client_type=='Existing Client')
		{
			if(empty($appointment_with))
			{
				$error=['code'=>INCOMPLETE_DATA,'message'=>'Failure! Data is incomplete. Please select with whom you have an appointment with'];
	        	echo json_encode($error);
	        	exit;
			}
			
			if(! getManagerInfo($appointment_with))
			{
			    //If the case manager does not exist
			    $error=['code'=>NO_RECORD_FOUND,'message'=>'Failure! Case Manager Not Found. Please select a valid case manager'];
	        	echo json_encode($error);
	        	exit;
			}
		}
		else if($client_type=='New Client')
		{
			//New Client
			if(empty($case_type))
			{
				$error=['code'=>INCOMPLETE_DATA,'message'=>'Failure! Data is incomplete. Please select a case type'];
	        	echo json_encode($error);
	        	exit;
			}
			
			if(empty($address))
			{
				$error=['code'=>INCOMPLETE_DATA,'message'=>'Failure! Data is incomplete. Please enter your address'];
	        	echo json_encode($error);
	        	exit;
			}
		}
		else
		{
		    $error=['code'=>INCOMPLETE_DATA,'message'=>'Failure! Data is incomplete. Please select a valid Client Type'];
	        	echo json_encode($error);
	        	exit;
		}

		//Following code will execute if all the required fields are set

		$insertQuery="INSERT INTO tbl_tokens(case_no,address,email_id,case_type,type,name,contact_no,user_id,created_by,created_on,token_send
	                        ) VALUES('".$case_no."','".$address."','".$email_id."','".$case_type."','".$client_type."','".$name."','".$contact."','".$appointment_with."','1',now(),'".$token_send."')";
	                
	                
					$insertClient=$db->prepare($insertQuery);
					if($insertClient->execute())
					{
							//Success
						sendSMS();
						$error=['code'=>SUCCESS,'message'=>'Check-In Successful'];
			        	echo json_encode($error);
			        	exit;

					}
					else
					{
							//Failure

						$error=['code'=>INSERT_ERROR,'message'=>'Failure in checking-in. Please try again.'];
			        	echo json_encode($error);
			        	exit;

					}

	}
	else
	{
		$error=['code'=>INCOMPLETE_DATA,'message'=>'Failure! Data is incomplete'];
        	echo json_encode($error);
        	exit;
	}

function sendSMS()
{
    
    global $appointment_with;
    
    global $db;
    global $name;
    global $contact;
    
     $to       = 'appointment@dsdlawfirm.com'; //Default email to send checkin info 
	if(!empty($appointment_with))
	{
	   
	        	//-----------Getting User info to send mail--------------------------//

		      $manager=getManagerInfo($appointment_with);
		      
              if(!empty($manager))
              {
                    if(! empty($manager['email']))
                   {
                      $to       = $manager['email']; //Get email ID of the manager
                   }
                	 
              }
              
        	 
	}

	      $subject  = 'DSD Reception: Client Checked-In';
    	  $from     =  "mailer@dsdlawfirm.com";
    	  $headers  = 'From:'.$from ."\n".'MIME-Version: 1.0' . "\n";
    	  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\n";
    	  $message = '<p>A Client has checked-in from the Reception software</p>				
    				 <strong>Name:</strong>'.$name.'<br>
    				 <strong>Contact No.: </strong>'.$contact.'<br>			 
    				 <b>Regards,</b><br>
    				 DSD Reception Team.';	  
    	 // $mailsend = mail('appointment@dsdlawfirm.com', $subject, $message, $headers);
    	  $mailsend = mail($to, $subject, $message, $headers);
                	  
        	if(isset($mailsend))
            {

                $insertEmail ="insert into send_mail SET user_id='".$appointment_with."',disc=\"".$message."\",subject='".$subject."',created_by='1',created_date=now()";
                $insertEmailExecute= $db->prepare($insertEmail);
                $insertEmailExecute->execute();
            
            }
	
}

function getManagerInfo($id)
{
    //Returns details of the manager if it exists else false 
    global $db;
    
    	//-----------Getting User info to send mail--------------------------//

		  $selectQuery   = "SELECT id,email,contact,alternate_number FROM admin WHERE status ='0' AND id='".trim($id)."'";

              $result  = $db->prepare($selectQuery);
              $result->execute();
              $fetchResult = $result->fetchAll(\PDO::FETCH_ASSOC);	  
              //echo $fetchValues['email'];
              if($result->rowCount()>0)
              {
                   $row=$fetchResult[0]; //Get the first row
                   return $row;
              } 
              
              return false; //No record found
}

?>