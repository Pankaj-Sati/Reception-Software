<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
//get database connection
include_once 'database.php';
include_once 'error_constants.php'; //This file contains all the codes that we send in case of error or success

if(empty($_REQUEST['contact']))
{
	$error=['code'=>INCOMPLETE_DATA,'message'=>'Incomplete Data'];
		echo json_encode($error);
		exit;
}

//Following lines will execute if contact number is received
$contact=intval($_REQUEST['contact']);
 
$database = new Database();
$db = $database->getConnection();

if($db==false)
{
	$error=['code'=>DATABASE_CONNECTION_ERROR,'message'=>'Database Connection Error'];
        	echo json_encode($error);
        	exit;
}

$selectQuery="select * from tbl_tokens where contact_no=".$contact." ORDER BY created_on DESC";

$client_details=$db->prepare($selectQuery);
$client_details->execute();
$get_client=$client_details->fetch(\PDO::FETCH_ASSOC);
	if($client_details->rowCount() > 0)
	{
		echo json_encode($get_client); 
	}
	else
	{
		$error=['code'=>NO_RECORD_FOUND,'message'=>'Record not found'];
		echo json_encode($error);
	}

?>